import WellNestApp from "@/components/WellNestApp";

const Index = () => {
  return <WellNestApp />;
};

export default Index;
