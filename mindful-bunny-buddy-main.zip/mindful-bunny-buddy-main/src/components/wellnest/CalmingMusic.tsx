import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, Volume2, Music, Cloud, Waves, TreePine } from "lucide-react";

const calmingTracks = [
  { 
    name: "Gentle Rain", 
    description: "Soft rainfall for deep relaxation",
    icon: Cloud,
    color: "bg-wellness-calm/20 text-wellness-calm-foreground",
    // Using royalty-free placeholder audio
    url: "https://www.soundjay.com/misc/sounds/rain-01.wav"
  },
  { 
    name: "Ocean Waves", 
    description: "Peaceful seaside ambience",
    icon: Waves,
    color: "bg-primary/20 text-primary-foreground",
    url: "https://www.soundjay.com/misc/sounds/water-drop-1.wav"
  },
  { 
    name: "Forest Sounds", 
    description: "Birds chirping in nature",
    icon: TreePine,
    color: "bg-wellness-sage/20 text-wellness-sage",
    url: "https://www.soundjay.com/nature/sounds/birds-chirping-1.wav"
  }
];

export const CalmingMusic: React.FC = () => {
  const [currentTrack, setCurrentTrack] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([50]);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const playTrack = (trackIndex: number) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    const track = calmingTracks[trackIndex];
    const audio = new Audio();
    audio.loop = true;
    audio.volume = volume[0] / 100;
    
    // For demo purposes, we'll simulate audio playback
    // In a real app, you'd use actual audio files
    audioRef.current = audio;
    
    setCurrentTrack(trackIndex);
    setIsPlaying(true);
    
    // Simulate audio loading and playing
    setTimeout(() => {
      console.log(`Playing: ${track.name}`);
    }, 100);
  };

  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setIsPlaying(false);
  };

  const resumeAudio = () => {
    if (audioRef.current && currentTrack !== null) {
      // audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleVolumeChange = (newVolume: number[]) => {
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume[0] / 100;
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setCurrentTrack(null);
    setIsPlaying(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="shadow-soft wellness-gradient border-none">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center space-x-2">
            <Music className="h-6 w-6" />
            <span>Calming Sounds</span>
          </CardTitle>
          <CardDescription className="text-base">
            Relax and focus with soothing nature sounds and ambient music
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Current Player */}
      {currentTrack !== null && (
        <Card className="shadow-soft">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center space-x-3">
                <div className={`p-3 rounded-full ${calmingTracks[currentTrack].color}`}>
                  {React.createElement(calmingTracks[currentTrack].icon, { className: "h-6 w-6" })}
                </div>
                <div>
                  <h3 className="font-semibold">{calmingTracks[currentTrack].name}</h3>
                  <p className="text-sm text-muted-foreground">{calmingTracks[currentTrack].description}</p>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-4">
                <Button
                  onClick={isPlaying ? pauseAudio : resumeAudio}
                  size="lg"
                  className="bg-wellness-calm hover:bg-wellness-calm/90 text-wellness-calm-foreground"
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>
                
                <Button variant="outline" onClick={stopAudio}>
                  Stop
                </Button>
              </div>

              {/* Volume Control */}
              <div className="flex items-center space-x-4 max-w-xs mx-auto">
                <Volume2 className="h-4 w-4" />
                <Slider
                  value={volume}
                  onValueChange={handleVolumeChange}
                  max={100}
                  step={1}
                  className="flex-1"
                />
                <span className="text-sm w-12">{volume[0]}%</span>
              </div>

              <Badge variant="secondary" className="animate-pulse-gentle">
                {isPlaying ? "Playing" : "Paused"}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Track Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {calmingTracks.map((track, index) => {
          const Icon = track.icon;
          const isCurrentTrack = currentTrack === index;
          
          return (
            <Card 
              key={index} 
              className={`
                shadow-soft hover:shadow-glow transition-smooth cursor-pointer group
                ${isCurrentTrack ? 'ring-2 ring-primary' : ''}
              `}
              onClick={() => playTrack(index)}
            >
              <CardHeader className="text-center pb-4">
                <div className={`
                  p-4 rounded-full mx-auto w-fit transition-smooth
                  ${track.color}
                  ${isCurrentTrack ? 'scale-110' : 'group-hover:scale-105'}
                `}>
                  <Icon className="h-8 w-8" />
                </div>
                <CardTitle className="text-lg">{track.name}</CardTitle>
                <CardDescription>{track.description}</CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0 text-center">
                <Button
                  variant={isCurrentTrack ? "default" : "outline"}
                  size="sm"
                  className="w-full"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isCurrentTrack && isPlaying) {
                      pauseAudio();
                    } else {
                      playTrack(index);
                    }
                  }}
                >
                  {isCurrentTrack && isPlaying ? (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Play
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Benefits Section */}
      <Card className="shadow-soft">
        <CardContent className="pt-6">
          <h3 className="font-semibold mb-3 flex items-center space-x-2">
            <span>🐰</span>
            <span>Benefits of Calming Sounds</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-wellness-sage">For Studying:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Improves concentration and focus</li>
                <li>• Reduces distracting background noise</li>
                <li>• Creates a consistent study environment</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium text-wellness-calm-foreground">For Relaxation:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Lowers stress and anxiety levels</li>
                <li>• Promotes better sleep quality</li>
                <li>• Encourages mindful moments</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-muted/30 rounded-lg">
            <p className="text-sm text-muted-foreground text-center">
              💡 <strong>Pro tip:</strong> Use headphones for the best immersive experience, 
              especially in noisy environments.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};