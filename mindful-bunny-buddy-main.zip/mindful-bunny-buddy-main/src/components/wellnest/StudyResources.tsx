import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ExternalLink, Search, BookOpen, Code, Calculator, Globe, Lightbulb } from "lucide-react";

const studyResources = [
  { name: "Khan Academy", url: "https://www.khanacademy.org", category: "General", icon: BookOpen, description: "Free courses in math, science, programming, and more" },
  { name: "Coursera", url: "https://www.coursera.org", category: "University", icon: Lightbulb, description: "University-level courses from top institutions" },
  { name: "freeCodeCamp", url: "https://www.freecodecamp.org", category: "Programming", icon: Code, description: "Learn to code with interactive lessons and projects" },
  { name: "edX", url: "https://www.edx.org", category: "University", icon: BookOpen, description: "High-quality courses from MIT, Harvard, and other universities" },
  { name: "W3Schools", url: "https://www.w3schools.com", category: "Programming", icon: Globe, description: "Web development tutorials and references" },
  { name: "MIT OpenCourseWare", url: "https://ocw.mit.edu", category: "University", icon: Lightbulb, description: "Free lecture notes, exams, and videos from MIT" },
  { name: "Wolfram Alpha", url: "https://www.wolframalpha.com", category: "Math", icon: Calculator, description: "Computational engine for mathematics and science" },
  { name: "Udemy", url: "https://www.udemy.com", category: "Skills", icon: BookOpen, description: "Practical skills and professional development courses" },
  { name: "GeeksforGeeks", url: "https://www.geeksforgeeks.org", category: "Programming", icon: Code, description: "Programming tutorials and interview preparation" },
  { name: "ApnaCollege", url: "https://www.apnacollege.in", category: "Programming", icon: Code, description: "Programming courses in Hindi and English" },
  { name: "Great Learning", url: "https://www.greatlearning.in", category: "Skills", icon: Lightbulb, description: "Professional courses in data science, AI, and more" },
  { name: "LinkedIn Learning", url: "https://www.linkedin.com/learning", category: "Professional", icon: BookOpen, description: "Business, technology, and creative skills training" }
];

const productiveActivities = [
  "📚 Reading books or eBooks on topics that interest you",
  "🧘‍♀️ Practicing mindfulness or meditation (try apps like Headspace)",
  "🎨 Learning a new creative skill like drawing, music, or writing",
  "🏃‍♂️ Physical exercise, yoga, or outdoor activities",
  "✍️ Creative writing, journaling, or blogging",
  "🎧 Listening to educational podcasts or audiobooks",
  "🤝 Volunteering for causes you care about",
  "👥 Organizing study groups with friends or classmates",
  "🌱 Gardening or caring for plants",
  "🍳 Learning to cook healthy and delicious meals"
];

const categories = ["All", "General", "Programming", "University", "Math", "Skills", "Professional"];

export const StudyResources: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredResources = studyResources.filter(resource => {
    const matchesSearch = resource.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || resource.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="shadow-soft wellness-gradient border-none">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Study Resources Hub</CardTitle>
          <CardDescription className="text-base">
            Curated learning resources to help you succeed in your studies and beyond
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="pt-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "secondary"}
                className="cursor-pointer transition-smooth hover:bg-primary/80"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredResources.map((resource, index) => {
          const Icon = resource.icon;
          return (
            <Card key={index} className="shadow-soft hover:shadow-glow transition-smooth group">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-smooth">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{resource.name}</CardTitle>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {resource.category}
                  </Badge>
                </div>
                <CardDescription className="text-sm">
                  {resource.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0">
                <Button
                  asChild
                  variant="outline"
                  size="sm"
                  className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-smooth"
                >
                  <a href={resource.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-3 w-3 mr-2" />
                    Visit Resource
                  </a>
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredResources.length === 0 && (
        <Card className="shadow-soft">
          <CardContent className="py-8 text-center">
            <div className="text-4xl mb-4">🔍</div>
            <p className="text-muted-foreground">
              No resources found for "{searchTerm}" in {selectedCategory === "All" ? "any category" : selectedCategory}.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Productive Activities Section */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lightbulb className="h-5 w-5 text-wellness-energy-foreground" />
            <span>Productive Activities</span>
          </CardTitle>
          <CardDescription>
            When you need a study break, try these enriching activities
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {productiveActivities.map((activity, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-smooth"
              >
                <span className="text-lg">{activity.charAt(0)}</span>
                <span className="text-sm">{activity.slice(2)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tips from Kinkin */}
      <Card className="shadow-soft">
        <CardContent className="pt-6">
          <h3 className="font-semibold mb-3 flex items-center space-x-2">
            <span>🐰</span>
            <span>Study Tips from Kinkin</span>
          </h3>
          
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Start with free resources before investing in paid courses</p>
            <p>• Practice consistently rather than cramming before exams</p>
            <p>• Join online communities related to your subjects</p>
            <p>• Take breaks to avoid burnout - your brain needs rest too!</p>
            <p>• Don't hesitate to ask for help when you're stuck</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};