import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, RefreshCw, Heart } from "lucide-react";

interface AffirmationsProps {
  ageGroup: "teen" | "youngAdult";
}

const affirmations = {
  teen: [
    "You are capable of amazing things! 🌟",
    "Every challenge is helping you grow stronger 💪",
    "Your uniqueness is your superpower ✨",
    "You have everything you need to succeed 🚀",
    "Progress, not perfection - you're doing great! 🎯",
    "Your potential is limitless 🌈",
    "You deserve kindness, especially from yourself 💚",
    "Every small step counts towards your dreams 👣",
    "You're braver than you believe and stronger than you seem 🦁",
    "Your voice matters and your ideas are valuable 📢",
    "You're exactly where you need to be right now 🗺️",
    "Mistakes are just learning opportunities in disguise 📚"
  ],
  youngAdult: [
    "You are building the life you want, one choice at a time 🏗️",
    "Your journey is unique and valuable ✨",
    "You have the wisdom to navigate life's challenges 🧭",
    "Balance is a practice, not a destination 🧘‍♀️",
    "You are worthy of the success you're working towards 👑",
    "Your experiences are shaping you into who you're meant to be 🌱",
    "You have the power to create positive change 💫",
    "Trust in your ability to figure things out 🔍",
    "Your efforts today are investments in your future 📈",
    "You're doing better than you think you are 🎖️",
    "It's okay to rest - you don't have to be productive all the time 🛋️",
    "Your mental health is just as important as your goals 🧠💚"
  ]
};

const motivationalQuotes = [
  "The only way to do great work is to love what you do. - Steve Jobs",
  "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
  "Your future self is watching you right now through your memories.",
  "Don't let yesterday take up too much of today. - Will Rogers",
  "The best time to plant a tree was 20 years ago. The second best time is now. - Chinese Proverb",
  "You are never too old to set another goal or to dream a new dream. - C.S. Lewis"
];

export const Affirmations: React.FC<AffirmationsProps> = ({ ageGroup }) => {
  const [currentAffirmation, setCurrentAffirmation] = useState("");
  const [currentQuote, setCurrentQuote] = useState("");
  const [favoriteAffirmations, setFavoriteAffirmations] = useState<string[]>([]);

  // Get random affirmation
  const getRandomAffirmation = () => {
    const affirmationList = affirmations[ageGroup];
    const randomIndex = Math.floor(Math.random() * affirmationList.length);
    return affirmationList[randomIndex];
  };

  // Get random quote
  const getRandomQuote = () => {
    const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
    return motivationalQuotes[randomIndex];
  };

  // Initialize with random affirmation and quote
  useEffect(() => {
    setCurrentAffirmation(getRandomAffirmation());
    setCurrentQuote(getRandomQuote());
    
    // Load favorites from localStorage
    const saved = localStorage.getItem("wellnest_favoriteAffirmations");
    if (saved) {
      setFavoriteAffirmations(JSON.parse(saved));
    }
  }, [ageGroup]);

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem("wellnest_favoriteAffirmations", JSON.stringify(favoriteAffirmations));
  }, [favoriteAffirmations]);

  const refreshAffirmation = () => {
    setCurrentAffirmation(getRandomAffirmation());
  };

  const refreshQuote = () => {
    setCurrentQuote(getRandomQuote());
  };

  const toggleFavorite = (affirmation: string) => {
    if (favoriteAffirmations.includes(affirmation)) {
      setFavoriteAffirmations(prev => prev.filter(fav => fav !== affirmation));
    } else {
      setFavoriteAffirmations(prev => [...prev, affirmation]);
    }
  };

  const isFavorite = (affirmation: string) => favoriteAffirmations.includes(affirmation);

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="shadow-soft wellness-gradient border-none">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center space-x-2">
            <Sparkles className="h-6 w-6" />
            <span>Daily Inspiration</span>
          </CardTitle>
          <CardDescription className="text-base">
            Positive affirmations and motivational quotes to brighten your day
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Daily Affirmation */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Your Daily Affirmation</span>
            <Badge variant="secondary" className="animate-pulse-gentle">
              {ageGroup === "teen" ? "Teen Edition" : "Young Adult"}
            </Badge>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center p-6 bg-wellness-sage-light rounded-lg border border-wellness-sage/20">
            <div className="text-4xl mb-4 animate-float">🐰</div>
            <p className="text-lg font-medium leading-relaxed text-wellness-sage">
              {currentAffirmation}
            </p>
          </div>
          
          <div className="flex justify-center space-x-3">
            <Button 
              onClick={refreshAffirmation}
              variant="outline"
              className="transition-smooth hover:bg-wellness-sage/10"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              New Affirmation
            </Button>
            
            <Button
              onClick={() => toggleFavorite(currentAffirmation)}
              variant={isFavorite(currentAffirmation) ? "default" : "outline"}
              className="transition-smooth"
            >
              <Heart className={`h-4 w-4 mr-2 ${isFavorite(currentAffirmation) ? 'fill-current' : ''}`} />
              {isFavorite(currentAffirmation) ? 'Favorited' : 'Add to Favorites'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Motivational Quote */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Motivational Quote</CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-center p-6 bg-wellness-calm/10 rounded-lg border border-wellness-calm/20">
            <p className="text-base italic leading-relaxed text-wellness-calm-foreground">
              "{currentQuote}"
            </p>
          </div>
          
          <div className="flex justify-center">
            <Button 
              onClick={refreshQuote}
              variant="outline"
              className="transition-smooth hover:bg-wellness-calm/10"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              New Quote
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Favorites Section */}
      {favoriteAffirmations.length > 0 && (
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Heart className="h-5 w-5 text-wellness-love fill-current" />
              <span>Your Favorite Affirmations</span>
              <Badge variant="secondary">{favoriteAffirmations.length}</Badge>
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              {favoriteAffirmations.map((affirmation, index) => (
                <div 
                  key={index}
                  className="p-4 bg-muted/30 rounded-lg flex items-center justify-between group hover:bg-muted/50 transition-smooth"
                >
                  <p className="text-sm flex-1 pr-4">{affirmation}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleFavorite(affirmation)}
                    className="opacity-70 group-hover:opacity-100 transition-smooth"
                  >
                    <Heart className="h-4 w-4 fill-current text-wellness-love" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Affirmations List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>All Affirmations</CardTitle>
          <CardDescription>
            Browse through all available affirmations for {ageGroup === "teen" ? "students" : "young adults"}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="grid gap-3">
            {affirmations[ageGroup].map((affirmation, index) => (
              <div 
                key={index}
                className="p-3 rounded-lg border hover:bg-muted/30 transition-smooth flex items-center justify-between group"
              >
                <p className="text-sm flex-1 pr-4">{affirmation}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleFavorite(affirmation)}
                  className="opacity-70 group-hover:opacity-100 transition-smooth"
                >
                  <Heart className={`h-4 w-4 ${isFavorite(affirmation) ? 'fill-current text-wellness-love' : ''}`} />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};