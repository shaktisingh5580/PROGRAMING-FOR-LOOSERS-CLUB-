import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Play, Pause, RotateCcw, Timer, Coffee } from "lucide-react";

export const PomodoroTimer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const totalTime = isBreak ? 5 * 60 : 25 * 60; // 5 min break or 25 min work
  const progress = ((totalTime - timeLeft) / totalTime) * 100;

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Timer effect
  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      timerRef.current = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      
      if (isBreak) {
        // Break finished, start new work session
        setIsBreak(false);
        setTimeLeft(25 * 60);
        alert("Break time is over! Ready for another focus session? 🐰");
      } else {
        // Work session finished
        setCompletedSessions(prev => prev + 1);
        setIsBreak(true);
        setTimeLeft(5 * 60);
        alert("Great work! Time for a 5-minute break 🌟");
      }
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isRunning, timeLeft, isBreak]);

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(isBreak ? 5 * 60 : 25 * 60);
  };

  const switchMode = () => {
    setIsRunning(false);
    setIsBreak(!isBreak);
    setTimeLeft(isBreak ? 25 * 60 : 5 * 60);
  };

  return (
    <div className="space-y-6">
      {/* Main Timer Card */}
      <Card className="shadow-soft text-center">
        <CardHeader>
          <CardTitle className="flex items-center justify-center space-x-2">
            <Timer className="h-6 w-6 text-primary" />
            <span>Focus Timer</span>
            <Badge variant={isBreak ? "secondary" : "default"}>
              {isBreak ? "Break Time" : "Focus Time"}
            </Badge>
          </CardTitle>
          <CardDescription>
            Stay focused with the Pomodoro technique - 25 minutes work, 5 minutes break
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Timer Display */}
          <div className="space-y-4">
            <div className="text-6xl font-mono font-bold text-primary">
              {formatTime(timeLeft)}
            </div>
            
            <Progress 
              value={progress} 
              className="h-3"
              color={isBreak ? "bg-wellness-calm" : "bg-wellness-sage"}
            />
            
            <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
              {isBreak ? <Coffee className="h-4 w-4" /> : <Timer className="h-4 w-4" />}
              <span>
                {isBreak ? "Take a break and relax" : "Stay focused on your task"}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex justify-center space-x-3">
            <Button
              onClick={toggleTimer}
              size="lg"
              className={`
                ${isBreak 
                  ? "bg-wellness-calm hover:bg-wellness-calm/90 text-wellness-calm-foreground" 
                  : "bg-wellness-sage hover:bg-wellness-sage/90 text-white"
                }
              `}
            >
              {isRunning ? (
                <>
                  <Pause className="h-5 w-5 mr-2" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="h-5 w-5 mr-2" />
                  {timeLeft === totalTime ? 'Start' : 'Resume'}
                </>
              )}
            </Button>
            
            <Button variant="outline" onClick={resetTimer}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            
            <Button variant="outline" onClick={switchMode}>
              {isBreak ? "Switch to Work" : "Switch to Break"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats Card */}
      <Card className="shadow-soft">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            <div className="space-y-2">
              <div className="text-2xl font-bold text-wellness-sage">{completedSessions}</div>
              <p className="text-sm text-muted-foreground">Sessions Today</p>
            </div>
            
            <div className="space-y-2">
              <div className="text-2xl font-bold text-wellness-energy-foreground">
                {Math.floor(completedSessions * 25 / 60)}h {(completedSessions * 25) % 60}m
              </div>
              <p className="text-sm text-muted-foreground">Total Focus Time</p>
            </div>
            
            <div className="space-y-2">
              <div className="text-2xl font-bold text-wellness-calm-foreground">
                {isBreak ? "Break" : "Focus"} Mode
              </div>
              <p className="text-sm text-muted-foreground">Current State</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tips Card */}
      <Card className="shadow-soft">
        <CardContent className="pt-6">
          <h3 className="font-semibold mb-3 flex items-center space-x-2">
            <span>🐰</span>
            <span>Focus Tips from Kinkin</span>
          </h3>
          
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Find a quiet, comfortable space free from distractions</p>
            <p>• During work sessions, focus on just one task</p>
            <p>• Use break time to stretch, hydrate, or take deep breaths</p>
            <p>• Turn off notifications to maintain deep focus</p>
            <p>• Celebrate each completed session - you're doing great!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};