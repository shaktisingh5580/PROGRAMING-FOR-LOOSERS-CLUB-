import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Smile, Frown, Angry, Meh, TrendingUp } from "lucide-react";

interface MoodTrackerProps {
  mood: string | null;
  setMood: (mood: string) => void;
  moodTimeline: Array<{ date: string; mood: string }>;
  ageGroup: "teen" | "youngAdult";
}

const moodOptions = [
  { 
    key: "happy", 
    label: "Happy", 
    icon: Smile, 
    emoji: "😊", 
    color: "bg-wellness-energy/20 text-wellness-energy-foreground border-wellness-energy/30",
    hoverColor: "hover:bg-wellness-energy/30"
  },
  { 
    key: "neutral", 
    label: "Okay", 
    icon: Meh, 
    emoji: "😐", 
    color: "bg-wellness-sage/20 text-wellness-sage border-wellness-sage/30",
    hoverColor: "hover:bg-wellness-sage/30"
  },
  { 
    key: "sad", 
    label: "Sad", 
    icon: Frown, 
    emoji: "😢", 
    color: "bg-wellness-calm/20 text-wellness-calm-foreground border-wellness-calm/30",
    hoverColor: "hover:bg-wellness-calm/30"
  },
  { 
    key: "angry", 
    label: "Angry", 
    icon: Angry, 
    emoji: "😠", 
    color: "bg-wellness-love/20 text-wellness-love-foreground border-wellness-love/30",
    hoverColor: "hover:bg-wellness-love/30"
  }
];

export const MoodTracker: React.FC<MoodTrackerProps> = ({ 
  mood, 
  setMood, 
  moodTimeline, 
  ageGroup 
}) => {
  const selectedMoodOption = moodOptions.find(option => option.key === mood);
  
  const getRecentMoodStreak = () => {
    const last7Days = moodTimeline.slice(-7);
    const happyDays = last7Days.filter(entry => entry.mood === 'happy').length;
    return { total: last7Days.length, happy: happyDays };
  };

  const streak = getRecentMoodStreak();

  return (
    <div className="space-y-4">
      <Card className="shadow-soft">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <span>How are you feeling today?</span>
                {selectedMoodOption && (
                  <span className="text-2xl">{selectedMoodOption.emoji}</span>
                )}
              </CardTitle>
              <CardDescription>
                {ageGroup === "teen" 
                  ? "Track your daily vibes and see your progress!" 
                  : "Monitor your emotional wellness journey"
                }
              </CardDescription>
            </div>
            
            {streak.total > 0 && (
              <div className="text-right">
                <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                  <TrendingUp className="h-4 w-4" />
                  <span>7-day streak</span>
                </div>
                <div className="text-lg font-semibold">
                  {streak.happy}/{streak.total} good days
                </div>
              </div>
            )}
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {moodOptions.map((option) => {
              const Icon = option.icon;
              const isSelected = mood === option.key;
              
              return (
                <Button
                  key={option.key}
                  variant="outline"
                  className={`
                    h-auto p-4 flex flex-col items-center space-y-2 transition-smooth
                    ${isSelected 
                      ? `${option.color} scale-105 shadow-glow` 
                      : `hover:scale-105 ${option.hoverColor}`
                    }
                  `}
                  onClick={() => setMood(option.key)}
                >
                  <div className="text-2xl">{option.emoji}</div>
                  <Icon className="h-4 w-4" />
                  <span className="text-sm font-medium">{option.label}</span>
                </Button>
              );
            })}
          </div>
          
          {mood && (
            <div className="mt-4 pt-4 border-t">
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="flex items-center space-x-2">
                  <span>Today's mood:</span>
                  <span className="capitalize">{mood}</span>
                  <span>{selectedMoodOption?.emoji}</span>
                </Badge>
                
                <p className="text-sm text-muted-foreground">
                  Great job checking in! 🐰💚
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};