import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Send, Heart } from "lucide-react";
import { synonyms, chatbotResponses } from "../WellNestApp";

interface ChatBotProps {
  ageGroup: "teen" | "youngAdult";
  mood: string | null;
}

interface ChatMessage {
  sender: "user" | "kinkin";
  text: string;
  timestamp: Date;
}

export const ChatBot: React.FC<ChatBotProps> = ({ ageGroup, mood }) => {
  const [chatLog, setChatLog] = useState<ChatMessage[]>([
    { 
      sender: "kinkin", 
      text: "Hi! I'm Kinkin the Bunny 🐰. How are you feeling today?",
      timestamp: new Date()
    }
  ]);
  const [userMessage, setUserMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatLog]);

  // Detect mood from user message
  const detectMoodFromMessage = (message: string): string => {
    const msg = message.toLowerCase();
    for (const moodKey in synonyms) {
      if (synonyms[moodKey as keyof typeof synonyms].some(word => msg.includes(word))) {
        return moodKey;
      }
    }
    return "fallback";
  };

  // Handle sending messages
  const handleSendMessage = async () => {
    if (!userMessage.trim()) return;

    // Add user message
    const newUserMessage: ChatMessage = {
      sender: "user",
      text: userMessage,
      timestamp: new Date()
    };
    setChatLog(prev => [...prev, newUserMessage]);
    setUserMessage("");
    setIsTyping(true);

    // Detect mood and generate response
    const detectedMood = detectMoodFromMessage(userMessage);
    const response = chatbotResponses[ageGroup]?.[detectedMood as keyof typeof chatbotResponses["teen"]] 
      || chatbotResponses[ageGroup]?.fallback;

    // Simulate typing delay
    setTimeout(() => {
      const kinkinResponse: ChatMessage = {
        sender: "kinkin",
        text: response,
        timestamp: new Date()
      };
      setChatLog(prev => [...prev, kinkinResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="text-2xl animate-float">🐰</div>
          <span>Chat with Kinkin</span>
          <Badge variant="secondary" className="flex items-center space-x-1">
            <Heart className="h-3 w-3 text-wellness-love" />
            <span>Always here for you</span>
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Chat Messages */}
        <div className="h-80 overflow-y-auto space-y-4 p-4 bg-muted/30 rounded-lg">
          {chatLog.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`
                  max-w-[80%] p-3 rounded-lg transition-smooth
                  ${message.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-wellness-sage-light border border-wellness-sage/30"
                  }
                `}
              >
                {message.sender === "kinkin" && (
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-sm">🐰</span>
                    <span className="text-xs font-medium text-wellness-sage">Kinkin</span>
                  </div>
                )}
                <p className="text-sm">{message.text}</p>
                <span className="text-xs opacity-70 mt-1 block">
                  {message.timestamp.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </span>
              </div>
            </div>
          ))}
          
          {/* Typing indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-wellness-sage-light border border-wellness-sage/30 p-3 rounded-lg">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-sm">🐰</span>
                  <span className="text-xs font-medium text-wellness-sage">Kinkin</span>
                </div>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-wellness-sage rounded-full animate-pulse" style={{ animationDelay: "0ms" }}></div>
                  <div className="w-2 h-2 bg-wellness-sage rounded-full animate-pulse" style={{ animationDelay: "150ms" }}></div>
                  <div className="w-2 h-2 bg-wellness-sage rounded-full animate-pulse" style={{ animationDelay: "300ms" }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={chatEndRef} />
        </div>

        {/* Message Input */}
        <div className="flex space-x-2">
          <Input
            value={userMessage}
            onChange={(e) => setUserMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message to Kinkin..."
            className="flex-1"
            disabled={isTyping}
          />
          <Button 
            onClick={handleSendMessage} 
            size="icon"
            disabled={!userMessage.trim() || isTyping}
            className="transition-smooth"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {/* Quick mood responses */}
        {!mood && (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Quick responses:</p>
            <div className="flex flex-wrap gap-2">
              {["I'm feeling great!", "Having a rough day", "Feeling stressed", "Pretty okay"].map((quickResponse) => (
                <Button
                  key={quickResponse}
                  variant="outline"
                  size="sm"
                  className="text-xs transition-smooth hover:bg-wellness-sage/20"
                  onClick={() => setUserMessage(quickResponse)}
                >
                  {quickResponse}
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};