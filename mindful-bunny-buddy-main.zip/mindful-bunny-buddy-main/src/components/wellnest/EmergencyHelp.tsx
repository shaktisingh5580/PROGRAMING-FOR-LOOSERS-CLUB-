import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, ExternalLink, Heart, Shield, Clock, Globe } from "lucide-react";

const emergencyHelplines = [
  { 
    region: "USA", 
    number: "988", 
    name: "Suicide & Crisis Lifeline",
    description: "24/7 free and confidential support",
    website: "https://988lifeline.org"
  },
  { 
    region: "UK", 
    number: "116 123", 
    name: "Samaritans",
    description: "Free support for anyone in emotional distress",
    website: "https://www.samaritans.org"
  },
  { 
    region: "India", 
    number: "9152987821", 
    name: "AASRA",
    description: "24/7 suicide prevention helpline",
    website: "http://www.aasra.info"
  },
  { 
    region: "Canada", 
    number: "1-833-456-4566", 
    name: "Talk Suicide Canada",
    description: "24/7 bilingual support",
    website: "https://talksuicide.ca"
  },
  { 
    region: "Australia", 
    number: "13 11 14", 
    name: "Lifeline",
    description: "24 hour crisis support and suicide prevention",
    website: "https://www.lifeline.org.au"
  }
];

const mentalHealthArticles = [
  {
    title: "Understanding and Managing Stress",
    description: "Learn effective strategies to identify and cope with daily stressors",
    link: "https://www.apa.org/topics/stress",
    category: "Stress Management"
  },
  {
    title: "Recognizing Signs of Anxiety",
    description: "Know when anxiety becomes a concern and how to seek help",
    link: "https://www.nimh.nih.gov/health/topics/anxiety-disorders",
    category: "Mental Health"
  },
  {
    title: "Building Emotional Resilience",
    description: "Develop the skills to bounce back from difficult times",
    link: "https://www.helpguide.org/articles/mental-health/building-better-mental-health.htm",
    category: "Resilience"
  },
  {
    title: "Healthy Sleep Habits",
    description: "Improve your mental wellness through better sleep practices",
    link: "https://www.sleepfoundation.org/how-sleep-works/why-do-we-need-sleep",
    category: "Sleep Health"
  }
];

const selfCareActivities = [
  "🫁 Practice deep breathing exercises (4-7-8 technique)",
  "🚶‍♀️ Take a walk in nature or fresh air",
  "💧 Drink a glass of water and have a healthy snack",
  "🧘‍♀️ Try a 5-minute guided meditation",
  "📱 Call or text a trusted friend or family member",
  "📝 Write down three things you're grateful for",
  "🎵 Listen to your favorite calming music",
  "🛁 Take a warm shower or bath",
  "📖 Read something positive or inspiring",
  "🎨 Engage in a creative activity (drawing, writing, etc.)"
];

export const EmergencyHelp: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Warning Header */}
      <Card className="shadow-soft border-wellness-love/30 bg-wellness-love/5">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center space-x-2 text-wellness-love-foreground">
            <Heart className="h-6 w-6 text-wellness-love" />
            <span>You Are Not Alone</span>
          </CardTitle>
          <CardDescription className="text-base">
            If you're in crisis or need immediate support, please reach out. Help is always available.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Crisis Notice */}
      <Card className="shadow-soft border-destructive/30 bg-destructive/5">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <Shield className="h-6 w-6 text-destructive mt-1 flex-shrink-0" />
            <div className="space-y-2">
              <h3 className="font-semibold text-destructive">If you're having thoughts of self-harm:</h3>
              <p className="text-sm text-destructive/80">
                Please contact emergency services (911, 112, 000) or a crisis helpline immediately. 
                Your life has value and there are people who want to help.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Crisis Helplines */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Phone className="h-5 w-5 text-primary" />
            <span>Crisis Helplines</span>
            <Badge variant="secondary" className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>24/7 Available</span>
            </Badge>
          </CardTitle>
          <CardDescription>
            Free, confidential support available around the clock
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="grid gap-4">
            {emergencyHelplines.map((helpline, index) => (
              <div 
                key={index}
                className="p-4 border rounded-lg hover:bg-muted/30 transition-smooth"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <Badge variant="outline" className="text-xs">
                      {helpline.region}
                    </Badge>
                    <h3 className="font-semibold">{helpline.name}</h3>
                  </div>
                  <a 
                    href={`tel:${helpline.number}`}
                    className="text-2xl font-mono font-bold text-primary hover:underline"
                  >
                    {helpline.number}
                  </a>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3">
                  {helpline.description}
                </p>
                
                <div className="flex space-x-2">
                  <Button 
                    asChild
                    size="sm"
                    className="bg-primary hover:bg-primary/90"
                  >
                    <a href={`tel:${helpline.number}`}>
                      <Phone className="h-3 w-3 mr-2" />
                      Call Now
                    </a>
                  </Button>
                  
                  <Button 
                    asChild
                    variant="outline" 
                    size="sm"
                  >
                    <a href={helpline.website} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-2" />
                      Website
                    </a>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Immediate Self-Care */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-wellness-love" />
            <span>Immediate Self-Care</span>
          </CardTitle>
          <CardDescription>
            Quick activities to help you feel more grounded right now
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {selfCareActivities.map((activity, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-smooth"
              >
                <span className="text-lg">{activity.charAt(0)}</span>
                <span className="text-sm">{activity.slice(2)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Mental Health Resources */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5 text-wellness-calm-foreground" />
            <span>Mental Health Resources</span>
          </CardTitle>
          <CardDescription>
            Helpful articles and information about mental wellness
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="grid gap-4">
            {mentalHealthArticles.map((article, index) => (
              <div 
                key={index}
                className="p-4 border rounded-lg hover:bg-muted/30 transition-smooth"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-sm">{article.title}</h3>
                  <Badge variant="outline" className="text-xs ml-2">
                    {article.category}
                  </Badge>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3">
                  {article.description}
                </p>
                
                <Button 
                  asChild
                  variant="outline" 
                  size="sm"
                >
                  <a href={article.link} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-3 w-3 mr-2" />
                    Read Article
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Support Message */}
      <Card className="shadow-soft wellness-gradient border-none">
        <CardContent className="pt-6 text-center">
          <div className="text-4xl mb-4">🐰💚</div>
          <h3 className="font-semibold mb-2">Remember, seeking help is a sign of strength</h3>
          <p className="text-muted-foreground text-sm max-w-2xl mx-auto">
            You matter, your feelings are valid, and there are people who care about you. 
            It's okay to not be okay, and it's important to reach out when you need support. 
            Kinkin and the WellNest community believe in you! 🌟
          </p>
        </CardContent>
      </Card>
    </div>
  );
};