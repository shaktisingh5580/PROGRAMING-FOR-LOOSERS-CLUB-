import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, GraduationCap } from "lucide-react";

interface AgeSelectionProps {
  onSelectAge: (ageGroup: "teen" | "youngAdult") => void;
}

export const AgeSelection: React.FC<AgeSelectionProps> = ({ onSelectAge }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background wellness-gradient p-4">
      <div className="w-full max-w-2xl space-y-8">
        {/* Welcome Header */}
        <div className="text-center space-y-4">
          <div className="text-8xl animate-float mb-4">🐰</div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Welcome to WellNest
          </h1>
          <p className="text-xl text-muted-foreground max-w-md mx-auto">
            Hi! I'm Kinkin, your wellness companion. Let's start by getting to know you better.
          </p>
        </div>

        {/* Age Group Selection Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card 
            className="cursor-pointer transition-smooth hover:shadow-glow hover:-translate-y-1 shadow-soft group"
            onClick={() => onSelectAge("teen")}
          >
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <div className="p-4 rounded-full bg-wellness-energy/20 group-hover:bg-wellness-energy/30 transition-smooth">
                  <Users className="h-8 w-8 text-wellness-energy-foreground" />
                </div>
              </div>
              <CardTitle className="text-2xl">Student (13-18)</CardTitle>
              <CardDescription className="text-base">
                Navigate school stress, friendships, and discover who you are
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• School and exam support</li>
                <li>• Peer pressure guidance</li>
                <li>• Study motivation</li>
                <li>• Emotional wellness</li>
              </ul>
              <Button 
                className="w-full mt-6 bg-wellness-energy hover:bg-wellness-energy/90 text-wellness-energy-foreground transition-smooth"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectAge("teen");
                }}
              >
                That's me! 🌟
              </Button>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer transition-smooth hover:shadow-glow hover:-translate-y-1 shadow-soft group"
            onClick={() => onSelectAge("youngAdult")}
          >
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <div className="p-4 rounded-full bg-wellness-calm/20 group-hover:bg-wellness-calm/30 transition-smooth">
                  <GraduationCap className="h-8 w-8 text-wellness-calm-foreground" />
                </div>
              </div>
              <CardTitle className="text-2xl">Young Adult (19-25)</CardTitle>
              <CardDescription className="text-base">
                Balance work, studies, and personal growth in this transition phase
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Career and life planning</li>
                <li>• Work-life balance</li>
                <li>• Independent living</li>
                <li>• Mindful productivity</li>
              </ul>
              <Button 
                className="w-full mt-6 bg-wellness-calm hover:bg-wellness-calm/90 text-wellness-calm-foreground transition-smooth"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectAge("youngAdult");
                }}
              >
                Perfect fit! ✨
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Footer Note */}
        <div className="text-center text-sm text-muted-foreground">
          <p>You can always change this later in your profile settings</p>
        </div>
      </div>
    </div>
  );
};