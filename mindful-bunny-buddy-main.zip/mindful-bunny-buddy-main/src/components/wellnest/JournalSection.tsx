import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Plus, Calendar, Trash2 } from "lucide-react";

interface JournalEntry {
  id: number;
  date: string;
  text: string;
}

interface JournalSectionProps {
  journals: JournalEntry[];
  onAddJournal: (text: string) => void;
}

export const JournalSection: React.FC<JournalSectionProps> = ({ journals, onAddJournal }) => {
  const [newEntry, setNewEntry] = useState("");
  const [isWriting, setIsWriting] = useState(false);

  const handleSubmit = () => {
    if (!newEntry.trim()) return;
    onAddJournal(newEntry);
    setNewEntry("");
    setIsWriting(false);
  };

  const journalPrompts = [
    "What made me smile today?",
    "One thing I'm grateful for:",
    "A challenge I overcame:",
    "My mood today and why:",
    "Something I learned about myself:",
    "A goal I'm working towards:"
  ];

  return (
    <div className="space-y-6">
      {/* New Entry Card */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <span>My Wellness Journal</span>
          </CardTitle>
          <CardDescription>
            Express your thoughts, track your progress, and reflect on your journey
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {!isWriting ? (
            <div className="space-y-4">
              <Button 
                onClick={() => setIsWriting(true)} 
                className="w-full bg-wellness-sage hover:bg-wellness-sage/90 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Write a new entry
              </Button>
              
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Need inspiration? Try these prompts:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {journalPrompts.slice(0, 4).map((prompt, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-left justify-start h-auto p-2 text-xs hover:bg-wellness-sage/10"
                      onClick={() => {
                        setNewEntry(prompt + " ");
                        setIsWriting(true);
                      }}
                    >
                      {prompt}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <Textarea
                value={newEntry}
                onChange={(e) => setNewEntry(e.target.value)}
                placeholder="What's on your mind today? How are you feeling?"
                className="min-h-32 resize-none"
                autoFocus
              />
              
              <div className="flex space-x-2">
                <Button 
                  onClick={handleSubmit}
                  disabled={!newEntry.trim()}
                  className="bg-wellness-sage hover:bg-wellness-sage/90 text-white"
                >
                  Save Entry
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsWriting(false);
                    setNewEntry("");
                  }}
                >
                  Cancel
                </Button>
              </div>
              
              <p className="text-xs text-muted-foreground">
                Your entries are saved locally and private to you 🐰💚
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Journal Entries */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Your Entries</h3>
          <Badge variant="secondary">
            {journals.length} {journals.length === 1 ? 'entry' : 'entries'}
          </Badge>
        </div>

        {journals.length === 0 ? (
          <Card className="shadow-soft">
            <CardContent className="py-8 text-center">
              <div className="text-4xl mb-4">📖</div>
              <p className="text-muted-foreground">
                No journal entries yet. Start writing to track your wellness journey!
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {journals.map((entry) => (
              <Card key={entry.id} className="shadow-soft hover:shadow-glow transition-smooth">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{entry.date}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">
                    {entry.text}
                  </p>
                  
                  <div className="mt-4 pt-3 border-t flex justify-end">
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive">
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};