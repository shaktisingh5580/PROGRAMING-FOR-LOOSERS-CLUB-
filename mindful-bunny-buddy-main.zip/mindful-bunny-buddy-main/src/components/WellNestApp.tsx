import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Users, Timer, BookOpen, Music, Sun, Moon, Sparkles } from "lucide-react";
import { AgeSelection } from "./wellnest/AgeSelection";
import { MoodTracker } from "./wellnest/MoodTracker";
import { ChatBot } from "./wellnest/ChatBot";
import { JournalSection } from "./wellnest/JournalSection";
import { PomodoroTimer } from "./wellnest/PomodoroTimer";
import { StudyResources } from "./wellnest/StudyResources";
import { CalmingMusic } from "./wellnest/CalmingMusic";
import { Affirmations } from "./wellnest/Affirmations";
import { EmergencyHelp } from "./wellnest/EmergencyHelp";

export const synonyms = {
  happy: ["happy", "joyful", "excited", "glad", "great", "cheerful", "awesome", "good", "fantastic", "delighted"],
  sad: ["sad", "lonely", "alone", "depressed", "down", "unhappy", "blue", "melancholy", "miserable", "tearful"],
  angry: ["angry", "mad", "frustrated", "upset", "annoyed", "furious", "irritated", "resentful", "enraged"],
  neutral: ["okay", "fine", "meh", "so-so", "alright", "normal", "neutral"]
};

export const chatbotResponses = {
  teen: {
    happy: "Yay! Awesome to hear that you're happy! Ready to crush your studies? 🌟",
    sad: "It's okay, buddy! Remember to take care of yourself and maybe jam to your favorite tunes! 🎵💚",
    angry: "Take a deep breath, you'll get through this! 🌸",
    neutral: "It's cool to take a break. How about a quick walk or some fresh air? 🌿",
    fallback: "I'm here to listen whenever you want to share. How are you feeling today? 🐰💝"
  },
  youngAdult: {
    happy: "That's wonderful. Hope you have a productive day ahead! ✨",
    sad: "It's perfectly fine to feel that way. Focus on self-care and maybe try some mindfulness. 🌸",
    angry: "Take a breather. This moment will pass. 🌊",
    neutral: "It's okay to take a break. Consider a relaxing walk or some meditation. 🧘‍♀️",
    fallback: "I'm here to listen whenever you want to share. How are you feeling today? 💚"
  }
};

const WellNestApp: React.FC = () => {
  const [ageGroup, setAgeGroup] = useState<"teen" | "youngAdult" | null>(null);
  const [mood, setMood] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  // Mood timeline: array of { date, mood }
  const [moodTimeline, setMoodTimeline] = useState(() => {
    const saved = localStorage.getItem("wellnest_moodTimeline");
    return saved ? JSON.parse(saved) : [];
  });

  // Journal entries: { id, date, text }
  const [journals, setJournals] = useState(() => {
    const saved = localStorage.getItem("wellnest_journals");
    return saved ? JSON.parse(saved) : [];
  });

  // Save mood to timeline & localStorage on change
  useEffect(() => {
    if (!mood) return;
    const today = new Date().toISOString().split("T")[0];

    const exists = moodTimeline.find((entry: any) => entry.date === today);
    if (!exists) {
      const updatedTimeline = [...moodTimeline, { date: today, mood }];
      setMoodTimeline(updatedTimeline);
      localStorage.setItem("wellnest_moodTimeline", JSON.stringify(updatedTimeline));
    }
  }, [mood, moodTimeline]);

  // Save journals to localStorage on change
  useEffect(() => {
    localStorage.setItem("wellnest_journals", JSON.stringify(journals));
  }, [journals]);

  // Dark mode effect
  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  // Add new journal entry
  const addJournal = (text: string) => {
    if (!text.trim()) return;
    const newEntry = { id: Date.now(), date: new Date().toLocaleString(), text };
    setJournals((prev: any[]) => [newEntry, ...prev]);
  };

  if (!ageGroup) {
    return <AgeSelection onSelectAge={setAgeGroup} />;
  }

  return (
    <div className="min-h-screen bg-background wellness-gradient">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="text-2xl animate-float">🐰</div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              WellNest
            </h1>
            <Badge variant="secondary" className="hidden sm:inline-flex">
              with Kinkin
            </Badge>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
              className="transition-smooth"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setAgeGroup(null);
                setMood(null);
              }}
            >
              Switch Profile
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 space-y-6">
        {/* Welcome Section */}
        <Card className="shadow-soft wellness-gradient border-none text-center">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="text-4xl animate-float">🐰</div>
              <Sparkles className="h-6 w-6 text-accent animate-pulse-gentle" />
            </div>
            <CardTitle className="text-2xl">
              Welcome back, {ageGroup === "teen" ? "friend" : "there"}! 
            </CardTitle>
            <CardDescription className="text-lg">
              How are you feeling today? Let Kinkin help you on your wellness journey.
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Mood Tracker */}
        <MoodTracker 
          mood={mood} 
          setMood={setMood} 
          moodTimeline={moodTimeline}
          ageGroup={ageGroup}
        />

        {/* Main Features Tabs */}
        <Tabs defaultValue="chat" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
            <TabsTrigger value="chat" className="flex items-center space-x-2">
              <Heart className="h-4 w-4" />
              <span className="hidden sm:inline">Chat</span>
            </TabsTrigger>
            <TabsTrigger value="journal" className="flex items-center space-x-2">
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Journal</span>
            </TabsTrigger>
            <TabsTrigger value="focus" className="flex items-center space-x-2">
              <Timer className="h-4 w-4" />
              <span className="hidden sm:inline">Focus</span>
            </TabsTrigger>
            <TabsTrigger value="study" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Study</span>
            </TabsTrigger>
            <TabsTrigger value="music" className="flex items-center space-x-2">
              <Music className="h-4 w-4" />
              <span className="hidden sm:inline">Music</span>
            </TabsTrigger>
            <TabsTrigger value="inspire" className="flex items-center space-x-2">
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Inspire</span>
            </TabsTrigger>
            <TabsTrigger value="help" className="flex items-center space-x-2">
              <Heart className="h-4 w-4 text-wellness-love" />
              <span className="hidden sm:inline">Help</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="space-y-6">
            <ChatBot ageGroup={ageGroup} mood={mood} />
          </TabsContent>

          <TabsContent value="journal" className="space-y-6">
            <JournalSection journals={journals} onAddJournal={addJournal} />
          </TabsContent>

          <TabsContent value="focus" className="space-y-6">
            <PomodoroTimer />
          </TabsContent>

          <TabsContent value="study" className="space-y-6">
            <StudyResources />
          </TabsContent>

          <TabsContent value="music" className="space-y-6">
            <CalmingMusic />
          </TabsContent>

          <TabsContent value="inspire" className="space-y-6">
            <Affirmations ageGroup={ageGroup} />
          </TabsContent>

          <TabsContent value="help" className="space-y-6">
            <EmergencyHelp />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default WellNestApp;